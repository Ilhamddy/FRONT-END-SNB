import React from 'react'
import CreateNews from './component/CreateNews'

const page = () => {
  return (
      <div>
          <CreateNews/>
    </div>
  )
}

export default page