export const baseUrl = "http://localhost:2000/api";
export const baseImage = "http://localhost:2000/";

