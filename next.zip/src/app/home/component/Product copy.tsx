import React from 'react'

const Product = () => {
    return (
        <section className='bg-third'>
            <div className='h-screen bg-cover md:mx-10 sm:mx-10 mx-3 py-10'>
                <div className='md:mx-10 sm:mx-10 '>


                </div>
            </div>
        </section >
    )
}

export default Product