import React from 'react'
import Contact from './component/Contact'

const Contactpage = () => {
    return (
        <main>
            <Contact />

        </main>
    )
}

export default Contactpage