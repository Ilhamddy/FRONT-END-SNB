import React from 'react'
import NewsDetail from './component/NewsDetail'

const page = () => {
    return (
        <NewsDetail />
    )
}

export default page