module.exports = {
  plugins: ["prettier-plugin-tailwindcss"],
};
